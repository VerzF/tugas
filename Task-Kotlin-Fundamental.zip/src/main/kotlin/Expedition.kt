/*
    TODO 5
        Buatlah pengecekan menggunakan IF dengan ketentuan berikut :
        - Apabila berat kurang dari atau sama dengan 1 kg, tampilkan Output berupa "biaya pengiriman adalah Rp 15.000"
        - Apabila berat kurang dari atau sama dengan 5 kg, tampilkan Output berupa "biaya pengiriman adalah Rp 30.000"
        - Apabila berat kurang dari atau sama dengan 10 kg, tampilkan Output berupa "biaya pengiriman adalah Rp 50.000"
*/
// Buat Pengecekan di function ini

fun expedition(berat: Int) {
    if (berat <= 1) {
        println("Biaya pengiriman adalah Rp 15.000")
    } else if (berat <= 5) {
        println("Biaya pengiriman adalah Rp 30.000")
    } else if (berat <= 10) {
        println("Biaya pengiriman adalah Rp 50.000")
    } else {
        println("Berat pengiriman melebihi 10 kg, silakan hubungi layanan pelanggan untuk informasi lebih lanjut.")
    }
}

fun main() {
    val berat = 20
    expedition(berat)
}