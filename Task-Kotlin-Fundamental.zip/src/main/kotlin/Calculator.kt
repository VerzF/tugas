/*
    TODO 3
        - buatlah return berupa perhitungan perkalian antara a dan b
        - (0 pada return dihapus)
*/
// Tulis Code di function ini

fun calculator(a: Int, b: Int): Int {
    return a * b
}

fun main () {
    val hasilPerkalian = calculator(200, 150)
    println("Hasil perkalian adalah $hasilPerkalian")
}