fun main() {
    /*
    TODO 1
        Buatlah variable dengan ketentuan berikut :
        - Variable dapat diubah sewaktu-waktu
        - Variable memiliki Identifier berupa myName
        - Variable memiliki tipe data berupa String
        - Variable memiliki Initialization berupa nama panggilan kamu
    */
    // Tulis Code dibawah ini

    var myName: String = "Allen"

    /*
    TODO 2
        Ubah Initialization pada varible myName diatas menjadi Nama Lengkap kamu
     */
    // Tulis Code dibawah ini

    myName = "Allendra Donny Irawan"

    /*
    TODO 4
        Buatlah Array dengan ketentuan berikut :
        - variabel Array bernama mobileMentors
        - Array berisi tipe data String
        - Index pada Array berisi ["Reza Kurniawan", "Raihan Zhaky", "Reynaldi", "Nabila Putri Syafarina Bukka", "Rahmad Noor Ikhsan"]
        - Ubah index yang berisi "Raihan Zhaky" pada Array menjadi "Raihan Zhaky Al-Hafizh"
        - Tampilkan index yang berisi "Raihan Zhaky Al-Hafizh"
    */
    // Tulis Code dibawah ini

    val mobileMentors = arrayOf(
        "Reza Kurniawan",
        "Raihan Zhaky",
        "Reynaldi",
        "Nabila Putri Syafarina Bukka",
        "Rahmad Noor Ikhsan"
    )

    mobileMentors[1] = "Raihan Zhaky Al-Hafizh"

    for ((index, mentor) in mobileMentors.withIndex()) {
        if (mentor == "Raihan Zhaky Al-Hafizh") {
            println("Index yang berisi 'Raihan Zhaky Al-Hafizh' adalah $index")
            break
        }
    }
    println(calculator(200, 150))

    expedition(20)
}